import api from "./Axios";
import { React, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import jwt_decode from "jwt-decode";
import { CssBaseline, Grid } from "@material-ui/core";

import {
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  TableContainer,
} from "@material-ui/core";

function AllComp() {
  const [ListOfComplaints, setListOfComplaints] = useState([]);
  const info = jwt_decode(sessionStorage.getItem("UserInfo"));

  useEffect(() => {
    async function getComp() {
      let res = await api.get("/complaints", {
        headers: {
          token: sessionStorage.getItem("UserInfo"),
        },
      });
      if (res.data.err) {
        console.log(res.data);
        alert(res.data.err);
      } else if (res.data) {
        setListOfComplaints(res.data);
      }
    }
    getComp();
  }, []);

  return (
    <>
      <CssBaseline />
      <Grid container >
      <h5>
        Hello {info.name} ({info.mail})
      </h5>
      </Grid>
      <br />
      <TableContainer>
        <Table aria-label="simple table">
          <TableHead>
            <TableRow>
              <TableCell>SUBJECT</TableCell>
              <TableCell>COMPLAINT TYPE</TableCell>
              <TableCell>COMPLAINT ID</TableCell>
              <TableCell>SEVERITY</TableCell>
              <TableCell>STATUS</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {ListOfComplaints.map((value, key) => {
              return (
                <TableRow key={value.id}>
                  <TableCell component="th" scope="row">
                    <Link to={{
                        pathname: "/complaints",
                        state: {id: value.id},
                      }}>
                      {value.subject}
                    </Link>
                  </TableCell>
                  <TableCell>{value.complainType}</TableCell>
                  <TableCell>
                    <Link to={{
                        pathname: "/complaints",
                        state: {id: value.id},
                      }}>
                      {value.id}
                    </Link>
                  </TableCell>
                  <TableCell>{value.severity}</TableCell>
                  <TableCell>{value.status}</TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>
    </>
  );
}
export default AllComp;
