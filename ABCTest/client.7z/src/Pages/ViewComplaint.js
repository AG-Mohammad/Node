import api from "./Axios";
import { React, useEffect, useState } from "react";
import { useLocation, useHistory } from "react-router-dom";
import formFields from "../Forms/ComplaintsForm";
import { Form } from "react-final-form";
import {
  Button,
  Typography,
  Grid,
  CssBaseline,
  Paper,
} from "@material-ui/core";
import jwt_decode from "jwt-decode";

function ViewComp() {
  const id = useLocation().state.id;

  const token = jwt_decode(sessionStorage.getItem("UserInfo"));
  let admin = token.isAdmin;
  let history = useHistory();
  const [complaintDetail, setComplaintDetail] = useState("");

  useEffect(() => {
    async function getComp() {
      let res = await api.get("/complaints/".concat(id));
      if (!res.data.err) {
        console.log(res.data[0]);
        setComplaintDetail(res.data[0]);
      }
    }
    async function adminView() {
      console.log("comp Id", id);
      await api.put(
        "/complaints/".concat(id),
        { id: token.id },
        { headers: { token: sessionStorage.getItem("UserInfo") } }
      );
    }

    if (admin) {
      adminView();
    }
    console.log("Data", complaintDetail);
    getComp();
  }, []);

  const onSubmit = async (values) => {
    console.log("putting status");
    async function updateStat() {
      await api.put(
        "/complaints/updatestatus/".concat(id),
        { changeStat: values.statusUpdate },
        { headers: { token: sessionStorage.getItem("UserInfo") } }
      );
    }
    updateStat();
    history.push("/");
  };

  return (
    <div style={{ padding: 16, margin: "auto", maxWidth: 600 }}>
      <CssBaseline />
      <Typography variant="h4" align="center" component="h1" gutterBottom>
        Login
      </Typography>

      <Form
        onSubmit={onSubmit}
        initialValues={{
          subject: complaintDetail.subject,
          stauts: complaintDetail.status,
          complaintId: complaintDetail.id,
          severity: complaintDetail.severity,
          complaintType: complaintDetail.complainType,
          openedBy: complaintDetail.openedBy,
          details: complaintDetail.description,
        }}
        render={({ handleSubmit, form, submitting, values }) => (
          <form onSubmit={handleSubmit} noValidate>
            <Paper style={{ padding: 16 }}>
              <Grid container alignItems="flex-start" spacing={6}>
                {formFields
                  .filter((item) => admin || item.display)
                  .map((item, idx) => (
                    <Grid item xs={item.size} key={idx}>
                      {item.field}
                    </Grid>
                  ))}
                <Grid></Grid>
              </Grid>
            </Paper>
          </form>
        )}
      />
    </div>
  );
}
export default ViewComp;
