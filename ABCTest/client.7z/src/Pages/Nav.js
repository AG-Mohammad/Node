import React from "react";
import { Link } from "react-router-dom";
import jwt_decode from "jwt-decode";
import { Box, Typography, Grid } from "@material-ui/core";

function Nav() {
  let Login = false;

  if (sessionStorage.getItem("UserInfo") != null) {
    const token = jwt_decode(sessionStorage.getItem("UserInfo"));
    Login = token.isLogged;
  } else {
    console.log("Not logged");
  }
  const deleteSession = (e) => {
    console.log("logout");
    sessionStorage.removeItem("UserInfo");
  };

  return (
    <Grid  spacing={10}>
      <Box display="flex" bgcolor="grey.200" p={2} alignItems="center">
        <Grid
          item
          xs={11}
          container
          direction="row"
          justify="flex-start"
          alignItems="center"
        >
          <Typography>
            <Link
              to="/"
              className="navbar-brand"
              style={{ textDecoration: "none" }}
            >
              ABC
            </Link>
          </Typography>
          <Grid item xs={3}>
            <h5>Complaints Management Portal</h5>
          </Grid>
        </Grid>
        <Grid item xs={9}>
          <Box>
            <Grid
              spacing={1}
              container
              direction="row"
              justify="flex-end"
              alignItems="center"
            >
              {
                {
                  true: [
                    <Grid item xs={3} key={1}>
                      <Link
                        to="/"
                        key={1}
                        style={{ textDecoration: "none" }}
                      >
                        View All Complaint
                      </Link>
                    </Grid>,
                    <Grid item xs={3} key={2}>
                      <Link
                        to="/complaints/new"
                        className="nav-item nav-link active p-2"
                        
                        style={{ textDecoration: "none" }}
                      >
                        Create Complaint
                      </Link>
                    </Grid>,
                    <Grid item xs={3} key={3}>
                      <a
                        href="/"
                        className="nav-item nav-link active p-2"
                        onClick={deleteSession}
                        key={4}
                        style={{ textDecoration: "none" }}
                      >
                        Sign Out
                      </a>
                    </Grid>,
                  ],
                  false: (
                    <Link
                      to="/"
                      className="nav-item nav-link active p-2"
                      style={{ textDecoration: "none" }}
                    >
                      Sign In
                    </Link>
                  ),
                }[Login]
              }
            </Grid>
          </Box>
        </Grid>
      </Box>
    </Grid>
  );
}
export default Nav;
