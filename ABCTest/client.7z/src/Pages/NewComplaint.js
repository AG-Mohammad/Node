import React from "react";
import { Form } from "react-final-form";
import api from "./Axios";
import { useHistory } from "react-router-dom";
import formFields from "../Forms/NewComp";
import {
  Typography,
  Paper,
  Grid,
  Button,
  CssBaseline,
} from "@material-ui/core";
import jwt_decode from "jwt-decode";

function NewComp() {
  let history = useHistory();

  const validate = (values) => {
    const errors = {};
    if (!values.complaintType) {
      errors.complaintType = "Required";
    }
    if (!values.subject) {
      errors.subject = "Required";
    }
    if (!values.severity) {
      errors.severity = "Required";
    }
    if (!values.discription) {
      errors.discription = "Required";
    }
    if (!values.agree) {
      errors.agree = "Required";
    }
    if (!values.language) {
      errors.language = "Required";
    }
    return errors;
  };

  const onSubmit = async (valuse) => {
    console.log(valuse);
    const token = jwt_decode(sessionStorage.getItem("UserInfo"));
    let data = {
      userId: token.id,
      complainType: valuse.complaintType,
      subject: valuse.subject,
      severity: valuse.severity,
      description: valuse.discription,
      preferedLanguage: valuse.language,
      status: "Pending",
    };
    console.log(data);
    async function newComp() {
      let res = await api.post("/complaints/new", data);
      console.log(res);
      if (res.status === 200) {
        console.log("yup");
        history.push("/api/complaints");
      } else {
        console.log("nope");
      }
    }
    newComp();
  };

  return (
    <div style={{ padding: 16, margin: "auto", maxWidth: 600 }}>
      <CssBaseline />
      <Typography variant="h4" align="center" component="h1" gutterBottom>
        React Final Form
      </Typography>
      <Form
        onSubmit={onSubmit}
        initialValues={{
          complaintType: "",
          subject: "",
          discription: "",
          language: "",
          agree: false,
        }}
        validate={validate}
        render={({ handleSubmit, form, submitting, values }) => (
          <form onSubmit={handleSubmit} noValidate>
            <Paper style={{ padding: 16 }}>
              <Grid container alignItems="flex-start" spacing={2}>
                {formFields.map((item, idx) => (
                  <Grid item xs={item.size} key={idx}>
                    {item.field}
                  </Grid>
                ))}
                <Grid item xs={12} style={{ marginTop: 16 }}>
                  <Button
                    variant="contained"
                    color="primary"
                    type="submit"
                    disabled={submitting}
                  >
                    Submit
                  </Button>
                </Grid>
              </Grid>
            </Paper>
          </form>
        )}
      />
    </div>
  );
}
export default NewComp;
