import React from "react";
import api from "./Axios";
import { useEffect, useState } from "react";

function AllUsers() {
  const [ListOfUsers, setListOfUsers] = useState([]);

  useEffect(() => {
    async function listUsers() {
      let usersList = await api.get("/users");
      console.log(usersList.data);
      setListOfUsers(usersList.data);
    }
    listUsers();
  }, []);
  return (
    <div className="App">
      <table className="table">
        <thead>
          <tr>
            <th scope="col">Id</th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">Password</th>
            <th scope="col">Phone Number</th>
            <th scope="col">Education</th>
            <th scope="col">Gender</th>
            <th scope="col">Address</th>
            <th scope="col">Admin</th>
          </tr>
        </thead>
        <tbody>
          {ListOfUsers.map((value, key) => {
            return (
              <tr key={value.id}>
                <th scope="row">{value.id}</th>
                <td>{value.fName}</td>
                <td>{value.email}</td>
                <td>{value.password}</td>
                <td>{value.phoneNumber}</td>
                <td>{value.education}</td>
                <td>{value.gender}</td>
                <td>{value.address}</td>
                <td>{value.isAdmin & 1}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

export default AllUsers;
