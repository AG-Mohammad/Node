import React from "react";
import { Form } from "react-final-form";
import api from "./Axios";
import { useHistory, useLocation } from "react-router-dom";
import formFields from "../Forms/SignUp";
import {
  Typography,
  Paper,
  Grid,
  Button,
  CssBaseline,
} from "@material-ui/core";
function UserReg() {
  const type = useLocation().state.Type;
  let history = useHistory();
  console.log("Login type: ", type);

  const onSubmit = async (valuse) => {
    let res =null
    let data = {
      fName: valuse.fName,
      email: valuse.email,
      password: valuse.password,
      phoneNumber: valuse.phoneNumber,
      education: valuse.education,
      gender: valuse.gender,
      address: valuse.address,
    };
    async function signup() {
      if(type){
        res = await api.post("/users/signup", data);
      }else{
        res = await api.post("/users/signupforadmin", data);
      }
      
      console.log(data);
      if (!res.data.err) {
        console.log(res.data);
        history.push("/");
      } else {
        console.log("nope");
        alert(res.data.err);
      }
    }

    signup();
  };
  const validate = (values) => {
    const errors = {};
    if (!values.fName) {
      errors.fName = "Required";
    }
    if (!values.email) {
      errors.email = "Required";
    }
    if (!values.password) {
      errors.password = "Required";
    }
    if (!values.phoneNumber) {
      errors.phoneNumber = "Required";
    }
    if (!values.education) {
      errors.education = "Required";
    }
    if (!values.gender) {
      errors.gender = "Required";
    }
    if (!values.address) {
      errors.address = "Required";
    }
    return errors;
  };
  return (
    <div style={{ padding: 16, margin: "auto", maxWidth: 600 }}>
      <CssBaseline />
      <Typography variant="h4" align="center" component="h1" gutterBottom>
        Login
      </Typography>

      <Form
        onSubmit={onSubmit}
        initialValues={{
          fName: "",
          email: "",
          password: "",
          phoneNumber: "",
          education: " ",
          gender: " ",
          address: " ",
        }}
        validate={validate}
        render={({ handleSubmit, form, submitting, values }) => (
          <form onSubmit={handleSubmit} noValidate>
            <Paper style={{ padding: 16 }}>
              <Grid container alignItems="flex-start" spacing={2}>
                {formFields.filter(item => type||item.display).map((item, idx) => (
                  <Grid item xs={item.size} key={idx}>
                    {item.field}
                  </Grid>
                ))}
                <Grid item xs={12} style={{ marginTop: 16 }}>
                  <Button
                    variant="contained"
                    color="primary"
                    type="submit"
                    disabled={submitting}
                  >
                    Submit
                  </Button>
                </Grid>
              </Grid>
            </Paper>
          </form>
        )}
      />
    </div>
  );
}
export default UserReg;
