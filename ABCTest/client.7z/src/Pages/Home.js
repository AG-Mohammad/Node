import React from "react";
import { Form } from "react-final-form";
import api from "./Axios";
import formFields from "../Forms/Login";
import { Link } from "react-router-dom";
import {
  Typography,
  Paper,
  Grid,
  Button,
  CssBaseline,
} from "@material-ui/core";

function Home() {
  const validate = (values) => {
    const errors = {};
    if (!values.email) {
      errors.email = "Required";
    }
    if (!values.password) {
      errors.password = "Required";
    }
    return errors;
  };

  const onSubmit = async (valuse) => {
    async function login() {
      let res = await api.post("/users/signin", valuse);
      if (res.data.err) {
        alert(res.data.err);
      } else {
        sessionStorage.setItem("UserInfo", res.data);
        console.log(res.data);
        window.location.reload();
      }
    }
    login();
  };

  return (
    <div style={{ padding: 16, margin: "auto", maxWidth: 600 }}>
      <CssBaseline />
      <Typography variant="h4" align="center" component="h1" gutterBottom>
        Login
      </Typography>

      <Form
        onSubmit={onSubmit}
        initialValues={{ email: "", password: "" }}
        validate={validate}
        render={({ handleSubmit, form, submitting, values }) => (
          <form onSubmit={handleSubmit} noValidate>
            <Paper style={{ padding: 16 }}>
              <Grid container alignItems="flex-start" spacing={2}>
                {formFields.map((item, idx) => (
                  <Grid item xs={item.size} key={idx}>
                    {item.field}
                  </Grid>
                ))}
                <Grid item xs={12} style={{ marginTop: 16 }}>
                  <Button
                    variant="contained"
                    color="primary"
                    type="submit"
                    disabled={submitting}
                  >
                    Submit
                  </Button>
                </Grid>
              </Grid>
              <Grid spacing={1}>
                <Typography paragraph>
                  <Grid item style={{ marginTop: 16 }}>
                    {" "}
                    Not registered ?
                  </Grid>
                  <Grid item style={{ marginTop: 16 }}>
                    <Link
                      to={{
                        pathname: "/auth/signup",
                        state: { Type: 1 },
                      }}
                    >
                      Create Customer Account
                    </Link>
                  </Grid>
                  <Grid item style={{ marginTop: 16 }}>
                    <Link
                      to={{
                        pathname: "/auth/signup",
                        state: { Type: 0 },
                      }}
                    >
                      Create Admin Account
                    </Link>
                  </Grid>
                </Typography>
              </Grid>
            </Paper>
          </form>
        )}
      />
    </div>
  );
}
export default Home;
