import React, { useState } from "react";
import {
  TextField,
  Container,
  Typography,
  Checkbox,
  CssBaseline,
  Button,
} from "@material-ui/core";
import api from "./Axios";
import { useHistory } from "react-router-dom";

function AdminReg() {
  let history = useHistory();

  const [fName, setFName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");

  const onSubmit = (e) => {
    e.preventDefault();
    let data = {
      fName: fName,
      email: email,
      password: password,
      phoneNumber: phoneNumber,
      isAdmin: "1",
    };
    async function signup() {
      let res = await api.post("/users/signup", data);

      console.log(data);
      if (!res.data.err) {
        console.log(res.data);
        history.push("/");
      } else {
        console.log("nope");
        alert(res.data.err);
      }
    }

    signup();
  };
  return (
    <Container component="main" maxWidth="xs">
      <CssBaseline />
      <div className="">
        <Typography component="h1" variant="h5">
          Sign in
        </Typography>
        <form className="" onSubmit={onSubmit} method="post" autoComplete="off">
          <TextField
            variant="outlined"
            margin="normal"
            required
            fullWidth
            name="fName"
            label="Full Name"
            type="fName"
            id="fName"
            value={fName}
            onChange={(e) => setFName(e.target.value)}
            autoComplete="off"
          />

          <TextField
            variant="outlined"
            margin="normal"
            required
            fullWidth
            id="email"
            label="Email Address"
            name="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <TextField
            variant="outlined"
            margin="normal"
            required
            fullWidth
            name="password"
            label="Password"
            type="password"
            id="password"
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <TextField
            variant="outlined"
            margin="normal"
            required
            fullWidth
            name="phoneNumber"
            label="Phone Number"
            type="phone"
            id="phoneNumber"
            value={phoneNumber}
            onChange={(e) => setPhoneNumber(e.target.value)}
          />

          <Checkbox value="remember" color="primary" required />
          <label>Agree to terms</label>

          <Button
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            className=""
          >
            Sign Up
          </Button>
        </form>
      </div>
    </Container>
  );
}
export default AdminReg;
