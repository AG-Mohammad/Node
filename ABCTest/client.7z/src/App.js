import "./App.css";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import { useEffect } from "react";
import Nav from "./Pages/Nav";
import Home from "./Pages/Home";
import userReg from "./Pages/UserReg";
import adminReg from "./Pages/AdminReg";
import allComp from "./Pages/AllComplaints";
import newComp from "./Pages/NewComplaint";
import ViewComp from "./Pages/ViewComplaint";
import allUsers from "./Pages/AllUsers";
import jwt_decode from "jwt-decode";

function App() {
  let token = sessionStorage.getItem("UserInfo");

  useEffect(() => {
    if (token) {
      let token = jwt_decode(sessionStorage.getItem("UserInfo")).isLogged;
      console.log(token);
    } else {
      token = false;
      console.log(token);
    }
  }, [token]);

  function homePage() {
    if (token) return allComp;
    else return Home;
  }

  return (
    <div className="App">
      <Router>
        <Nav />

        <Switch>
          <Route path="/" exact component={homePage()} />
          <Route path="/auth/signup" exact component={userReg} />

          <Route path="/complaints/new" exact component={newComp} />
          <Route path="/complaints" component={ViewComp}/>

          <Route path="/api/users" component={allUsers} />
        </Switch>
      </Router>
    </div>
  );
}

export default App;
