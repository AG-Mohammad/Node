import { TextField, Select } from "mui-rff";
import { MenuItem, Button } from "@material-ui/core";
const formFields = [
  {
    size: 6,
    display: true,
    field: (
      <TextField
        label="Subject"
        name="subject"
        margin="none"
        inputProps={{ "aria-label": "naked", readOnly: true }}
      />
    ),
  },
  {
    size: 6,
    display: true,
    field: (
      <TextField
        label="STATUS"
        name="stauts"
        margin="none"
        inputProps={{ "aria-label": "naked", readOnly: true }}
      />
    ),
  },
  {
    size: 6,
    display: true,
    field: (
      <TextField
        label="COMPLAINT ID"
        name="complaintId"
        margin="none"
        inputProps={{ "aria-label": "naked", readOnly: true }}
      />
    ),
  },
  {
    size: 6,
    display: true,
    field: (
      <TextField
        label="SEVERITY"
        name="severity"
        margin="none"
        inputProps={{ "aria-label": "naked", readOnly: true }}
      />
    ),
  },

  {
    size: 6,
    display: true,
    field: (
      <TextField
        label="COMPLAINT TYPE"
        name="complaintType"
        margin="none"
        inputProps={{ "aria-label": "naked", readOnly: true }}
      />
    ),
  },
  {
    size: 6,
    display: true,
    field: (
      <TextField
        label="OPENED BY"
        name="openedBy"
        margin="none"
        inputProps={{ "aria-label": "naked", readOnly: true }}
      />
    ),
  },
  {
    size: 12,
    display: true,
    field: (
      <TextField
        name="details"
        label="DETAILS"
        inputProps={{ "aria-label": "naked", readOnly: true }}
      />
    ),
  },
  {
    size: 12,
    display: false,
    field: (
      <Select
        variant="outlined"
        name="statusUpdate"
        label="Update Status"
        formControlProps={{ margin: "none" }}
      >
        <MenuItem value="HS">HS</MenuItem>
        <MenuItem value="BS">BS</MenuItem>
      </Select>
    ),
  },
  {
    size: 12,
    display: false,
    field: (
      <Button
        variant="contained"
        color="primary"
        name="education"
        type="submit"
      >
        Update
      </Button>
    ),
  },
];

export default formFields;
