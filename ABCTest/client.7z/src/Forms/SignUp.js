import { TextField, Checkboxes, Select, Radios } from "mui-rff";
import { MenuItem } from "@material-ui/core";

const formFields = [
  {
    size: 12,
    display: true,
    field: (
      <TextField
        variant="outlined"
        label="Full Name"
        name="fName"
        type="text"
        margin="none"
        required={true}
        
      />
    ),
  },
  {
    size: 12,
    display: true,
    field: (
      <TextField
        variant="outlined"
        label="Email"
        name="email"
        margin="none"
        required={true}
        
      />
    ),
  },
  {
    size: 12,
    display: true,
    field: (
      <TextField
        variant="outlined"
        label="Password"
        name="password"
        type="password"
        margin="none"
        required={true}
      />
    ),
  },
  {
    size: 12,
    display: true,
    field: (
      <TextField
        variant="outlined"
        label="Phone Number"
        name="phoneNumber"
        type="tel"
        margin="none"
        required={true}
      />
    ),
  },
  {
    size: 12,
    display: false,
    field: (
      <Select
        variant="outlined"
        name="education"
        label="Education"
        formControlProps={{ margin: "none" }}
      >
        <MenuItem value="Account">HS</MenuItem>
        <MenuItem value="Others">BS</MenuItem>
      </Select>
    ),
  },
  {
    size: 12,
    display: false,
    field: (
      <Radios
        label="Gender"
        name="gender"
        formControlProps={{ margin: "none" }}
        radioGroupProps={{ row: true }}
        data={[
          { label: "Male", value: "Male" },
          { label: "Female", value: "Female" },
        ]}
      />
    ),
  },
  {
    size: 12,
    display: false,
    field: (
      <TextField
        variant="outlined"
        label="Address"
        name="address"
        type="text"
        margin="none"
        required={true}
        rows={4}
        multiline={true}
      />
    ),
  },
  {
    size: 0,
    display: true,
    field: (
      <Checkboxes
        name="agree"
        formControlProps={{ margin: "none" }}
        data={{ label: "Agree", value: true }}
      />
    ),
  },
];

export default formFields;
