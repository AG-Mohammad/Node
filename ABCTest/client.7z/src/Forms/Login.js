import { TextField } from "mui-rff";

const formFields = [
    {
      size: 12,
      field: (
        <TextField label="Email" name="email" margin="none" required={true} />
      ),
    },
    {
      size: 12,
      field: (
        <TextField
          label="Password"
          name="password"
          type="password"
          margin="none"
          required={true}
        />
      ),
    },
  ];

export default formFields