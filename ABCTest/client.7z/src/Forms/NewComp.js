import { TextField, Checkboxes, Select,Radios } from "mui-rff";
import { MenuItem } from "@material-ui/core";
const formFields = [
  {
    size: 12,
    field: (
      <Select
      variant="outlined"
        name="complaintType"
        label="Complaint Type"
        formControlProps={{ margin: "none" }}
      >
        <MenuItem value="Account">Account</MenuItem>
        <MenuItem value="Others">Others</MenuItem>
      </Select>
    ),
  },
  {
    size: 12,
    field: (
      <TextField variant="outlined" label="Subject" name="subject" margin="none" required={true} />
    ),
  },
  {
    size: 12,
    field: (
      <Select
      variant="outlined"
        name="severity"
        label="Severity"
        formControlProps={{ margin: "none" }}
      >
        <MenuItem value="Account">Urgent</MenuItem>
        <MenuItem value="Others">Important</MenuItem>
      </Select>
    ),
  },
  {
    size: 12,
    field: (
      <TextField
      variant="outlined"
        rows={4}
        label="Discription"
        name="discription"
        margin="none"
        rows={4}
        multiline={true}
        required={true}
      />
    ),
  },
  {
    size: 12,
    field: (
      <Radios
      
        label="Preferred Contact Language "
        name="language"
        formControlProps={{ margin: 'none' }}
        radioGroupProps={{ row: true }}
        data={[
          { label: 'Arabic', value: 'Arabic' },
          { label: 'English', value: 'English' },
        ]}
      />
    ),
  },
  {
    size: 0,
    field: (
      <Checkboxes
        name="agree"
        formControlProps={{ margin: "none" }}
        data={{ label: "Agree", value: true }}
      />
    ),
  },
];

export default formFields;
